#include "notpermited.h"
#include "ui_notpermited.h"
#include "finishsuccess.h"

notPermited::notPermited(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::notPermited)
{
    ui->setupUi(this);
}

notPermited::~notPermited()
{
    delete ui;
}

void notPermited::on_pushButton_clicked()
{


    //creating object
    finishSuccess nppt;

    //For opening 2nd Window  /Model approch
    nppt.setModal(true);
    nppt.exec();
}
