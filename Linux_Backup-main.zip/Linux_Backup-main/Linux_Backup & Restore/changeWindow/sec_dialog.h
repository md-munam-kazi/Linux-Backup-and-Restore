#ifndef SEC_DIALOG_H
#define SEC_DIALOG_H

#include <QDialog>

namespace Ui {
class Sec_Dialog;
}

class Sec_Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Sec_Dialog(QWidget *parent = 0);
    ~Sec_Dialog();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    int mmmx();

private:
    Ui::Sec_Dialog *ui;
};

#endif // SEC_DIALOG_H
