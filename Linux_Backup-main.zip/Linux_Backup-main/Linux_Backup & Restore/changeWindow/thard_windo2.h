#ifndef THARD_WINDO2_H
#define THARD_WINDO2_H

#include <QDialog>

namespace Ui {
class thard_windo2;
}

class thard_windo2 : public QDialog
{
    Q_OBJECT

public:
    explicit thard_windo2(QWidget *parent = 0);
    ~thard_windo2();

private:
    Ui::thard_windo2 *ui;
};

#endif // THARD_WINDO2_H
