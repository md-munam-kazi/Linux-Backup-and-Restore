#include "thard_windo.h"
#include "ui_thard_windo.h"
#include <QMessageBox>
#include "readwrite.h"


Thard_windo::Thard_windo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Thard_windo)
{
    ui->setupUi(this);
}

Thard_windo::~Thard_windo()
{
    delete ui;
}

void Thard_windo::on_pushButton_clicked()
{
    //creating object
     ReadWrite Rew;

    //For opening 2nd Window  /Model approch
    Rew.setModal(true);
    Rew.exec();
}
