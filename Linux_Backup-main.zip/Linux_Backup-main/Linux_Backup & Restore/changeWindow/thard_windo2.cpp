#include "thard_windo2.h"
#include "ui_thard_windo2.h"

thard_windo2::thard_windo2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::thard_windo2)
{
    ui->setupUi(this);
}

thard_windo2::~thard_windo2()
{
    delete ui;
}
