#ifndef THARD_WINDO_H
#define THARD_WINDO_H

#include <QDialog>

namespace Ui {
class Thard_windo;
}

class Thard_windo : public QDialog
{
    Q_OBJECT

public:
    explicit Thard_windo(QWidget *parent = 0);
    ~Thard_windo();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Thard_windo *ui;
};

#endif // THARD_WINDO_H
