#ifndef SHOWSUCCESSFULMESSAGE_H
#define SHOWSUCCESSFULMESSAGE_H

#include <QDialog>

namespace Ui {
class showSuccessFulMessage;
}

class showSuccessFulMessage : public QDialog
{
    Q_OBJECT

public:
    explicit showSuccessFulMessage(QWidget *parent = 0);
    ~showSuccessFulMessage();

private slots:
    void on_pushButton_clicked();

private:
    Ui::showSuccessFulMessage *ui;
};

#endif // SHOWSUCCESSFULMESSAGE_H
