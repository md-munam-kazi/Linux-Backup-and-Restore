#include "showprogressbar.h"
#include "ui_showprogressbar.h"
#include <QMessageBox>
#include "successfulbackup.h"

showProgressBar::showProgressBar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::showProgressBar)
{
    ui->setupUi(this);
}

showProgressBar::~showProgressBar()
{
    delete ui;
}

void showProgressBar::on_pushButton_clicked()
{
    //creating object
    successFulBackup ssfb;

    //For opening 2nd Window  /Model approch
    ssfb.setModal(true);
    ssfb.exec();
}
