#ifndef NOTPERMITED_H
#define NOTPERMITED_H

#include <QDialog>

namespace Ui {
class notPermited;
}

class notPermited : public QDialog
{
    Q_OBJECT

public:
    explicit notPermited(QWidget *parent = 0);
    ~notPermited();

private slots:
    void on_pushButton_clicked();

private:
    Ui::notPermited *ui;
};

#endif // NOTPERMITED_H
