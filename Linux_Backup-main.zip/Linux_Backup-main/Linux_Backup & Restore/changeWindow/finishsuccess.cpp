#include "finishsuccess.h"
#include "ui_finishsuccess.h"

finishSuccess::finishSuccess(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::finishSuccess)
{
    ui->setupUi(this);
}

finishSuccess::~finishSuccess()
{
    delete ui;
}
