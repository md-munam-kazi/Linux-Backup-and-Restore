#include "unsuccessfulmessage.h"
#include "ui_unsuccessfulmessage.h"
#include "finishsuccess.h"

unsuccessfulMessage::unsuccessfulMessage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::unsuccessfulMessage)
{
    ui->setupUi(this);
}

unsuccessfulMessage::~unsuccessfulMessage()
{
    delete ui;
}

void unsuccessfulMessage::on_pushButton_clicked()
{
    //creating object
    finishSuccess usf;

    //For opening 2nd Window  /Model approch
    usf.setModal(true);
    usf.exec();
}
