#ifndef READWRITE_H
#define READWRITE_H

#include <QDialog>

namespace Ui {
class ReadWrite;
}

class ReadWrite : public QDialog
{
    Q_OBJECT

public:
    explicit ReadWrite(QWidget *parent = 0);
    ~ReadWrite();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::ReadWrite *ui;
};

#endif // READWRITE_H
