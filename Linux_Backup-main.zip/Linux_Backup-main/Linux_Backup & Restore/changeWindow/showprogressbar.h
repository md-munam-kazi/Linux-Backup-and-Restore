#ifndef SHOWPROGRESSBAR_H
#define SHOWPROGRESSBAR_H

#include <QDialog>

namespace Ui {
class showProgressBar;
}

class showProgressBar : public QDialog
{
    Q_OBJECT

public:
    explicit showProgressBar(QWidget *parent = 0);
    ~showProgressBar();

private slots:
    void on_pushButton_clicked();

private:
    Ui::showProgressBar *ui;
};

#endif // SHOWPROGRESSBAR_H
