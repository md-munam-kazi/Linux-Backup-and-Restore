#include "sec_dialog.h"
#include "ui_sec_dialog.h"
#include <QMessageBox>
#include "thard_windo.h"
#include "thard_windo2.h"

#include <iostream>
#include <bits/stdc++.h>
#include <stdexcept>
#include <stdio.h>
#include <string>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
using namespace std;
char munam;
Sec_Dialog::Sec_Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Sec_Dialog)
{
    ui->setupUi(this);
}

Sec_Dialog::~Sec_Dialog()
{
    delete ui;
}
int Sec_Dialog::mmmx()
{
   char cwd[PATH_MAX];
   if (getcwd(cwd, sizeof(cwd)) != NULL)
   {
       printf("Current working dir: %s\n", cwd);
   }
   else
   {
       perror("getcwd() error");
       return 1;
   }
   //munam = cwd;

   printf("MD MUNAM KAZI : \n\n\n\n\n %s\n\n\n", cwd);
   return 0;
}


void Sec_Dialog::on_pushButton_clicked()
{
    //creating object
    mmmx();
    Thard_windo thardWindo;

    //For opening 3rd Window  /Model approch
    thardWindo.setModal(true);
    thardWindo.exec();


}

void Sec_Dialog::on_pushButton_2_clicked()
{
    //creating object
    thard_windo2 thardWindo2;

    //For opening 3rd Window  /Model approch
    thardWindo2.setModal(true);
    thardWindo2.exec();
    mmmx();
}


