#ifndef FINISHSUCCESS_H
#define FINISHSUCCESS_H

#include <QDialog>

namespace Ui {
class finishSuccess;
}

class finishSuccess : public QDialog
{
    Q_OBJECT

public:
    explicit finishSuccess(QWidget *parent = 0);
    ~finishSuccess();

private:
    Ui::finishSuccess *ui;
};

#endif // FINISHSUCCESS_H
