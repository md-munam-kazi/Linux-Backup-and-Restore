#ifndef UNSUCCESSFULMESSAGE_H
#define UNSUCCESSFULMESSAGE_H

#include <QDialog>

namespace Ui {
class unsuccessfulMessage;
}

class unsuccessfulMessage : public QDialog
{
    Q_OBJECT

public:
    explicit unsuccessfulMessage(QWidget *parent = 0);
    ~unsuccessfulMessage();

private slots:
    void on_pushButton_clicked();

private:
    Ui::unsuccessfulMessage *ui;
};

#endif // UNSUCCESSFULMESSAGE_H
