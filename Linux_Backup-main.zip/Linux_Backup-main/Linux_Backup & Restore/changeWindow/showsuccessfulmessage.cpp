#include "showsuccessfulmessage.h"
#include "ui_showsuccessfulmessage.h"
#include "finishsuccess.h"
#include <QMessageBox>

showSuccessFulMessage::showSuccessFulMessage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::showSuccessFulMessage)
{
    ui->setupUi(this);
}

showSuccessFulMessage::~showSuccessFulMessage()
{
    delete ui;
}

void showSuccessFulMessage::on_pushButton_clicked()
{
    //creating object
    finishSuccess fss;

    //For opening 2nd Window  /Model approch
    fss.setModal(true);
    fss.exec();
}
