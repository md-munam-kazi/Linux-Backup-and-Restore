#include "startbackup.h"
#include "ui_startbackup.h"
#include "showprogressbar.h"

startBackup::startBackup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::startBackup)
{
    ui->setupUi(this);
}

startBackup::~startBackup()
{
    delete ui;
}

void startBackup::on_pushButton_clicked()
{

    //creating object
    showProgressBar spb;

    //For opening 2nd Window  /Model approch
    spb.setModal(true);
    spb.exec();
}
