#include "readwrite.h"
#include "ui_readwrite.h"
#include <QMessageBox>
#include"startbackup.h"
#include "notpermited.h"

ReadWrite::ReadWrite(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ReadWrite)
{
    ui->setupUi(this);
}

ReadWrite::~ReadWrite()
{
    delete ui;
}

void ReadWrite::on_pushButton_clicked()
{
  //creating object
     startBackup stB;

    //For opening 2nd Window  /Model approch
    stB.setModal(true);
    stB.exec();
}

void ReadWrite::on_pushButton_2_clicked()
{
    //creating object
    notPermited npd;

    //For opening 2nd Window  /Model approch
    npd.setModal(true);
    npd.exec();
}
