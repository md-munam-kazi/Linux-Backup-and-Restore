#ifndef SUCCESSFULBACKUP_H
#define SUCCESSFULBACKUP_H

#include <QDialog>

namespace Ui {
class successFulBackup;
}

class successFulBackup : public QDialog
{
    Q_OBJECT

public:
    explicit successFulBackup(QWidget *parent = 0);
    ~successFulBackup();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::successFulBackup *ui;
};

#endif // SUCCESSFULBACKUP_H
