#include "successfulbackup.h"
#include "ui_successfulbackup.h"
#include <QMessageBox>
#include "showsuccessfulmessage.h"
#include "unsuccessfulmessage.h"
successFulBackup::successFulBackup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::successFulBackup)
{
    ui->setupUi(this);
}

successFulBackup::~successFulBackup()
{
    delete ui;
}

void successFulBackup::on_pushButton_clicked()
{

    //creating object
    showSuccessFulMessage ssfm;

    //For opening 2nd Window  /Model approch
    ssfm.setModal(true);
    ssfm.exec();
}

void successFulBackup::on_pushButton_2_clicked()
{
    //creating object
    unsuccessfulMessage usfm;
    //For opening 2nd Window  /Model approch
    usfm.setModal(true);
    usfm.exec();
}
