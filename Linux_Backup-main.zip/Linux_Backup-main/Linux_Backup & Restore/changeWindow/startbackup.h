#ifndef STARTBACKUP_H
#define STARTBACKUP_H

#include <QDialog>

namespace Ui {
class startBackup;
}

class startBackup : public QDialog
{
    Q_OBJECT

public:
    explicit startBackup(QWidget *parent = 0);
    ~startBackup();

private slots:
    void on_pushButton_clicked();

private:
    Ui::startBackup *ui;
};

#endif // STARTBACKUP_H
