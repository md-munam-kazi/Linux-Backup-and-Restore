#include "dialog.h"
#include "ui_dialog.h"

#include <iostream>
#include <stdlib.h>
#include <string>


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_button_ok_accepted()
{
//    QString command="ls";
//    system(command.toStdString().c_str());

    //system("pwd");
}
