//#include "password.h"
//#include "ui_password.h"
//#include "input_pass.h"
// //#include <QDialog>

//password::password(QWidget *parent) :
//    QDialog(parent),
//    ui(new Ui::password)
//{
//    ui->setupUi(this);
//}

//password::~password()
//{
//    delete ui;
//}

//void password::on_lineEdit_cursorPositionChanged(int arg1, int arg2)
//{

//}

//void password::on_pushButton_clicked()
//{
//    input_pass ip;


//    ip.setModal(true);
//    ip.exec();
//}
