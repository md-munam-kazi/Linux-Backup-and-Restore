//#include "input_pass.h"


//#include <iostream>
//#include <bits/stdc++.h>
//#include <stdexcept>
//#include <stdio.h>
//#include <string>
//#include <unistd.h>
//#include <stdio.h>
//#include <limits.h>
//#include "stdlib.h"
//using namespace std;

//input_pass::input_pass()
//{
//cout<<"Please Enter Your Root Password.. \n\n\n";
//system("sudo rear dump");
//system("exit");
//}
