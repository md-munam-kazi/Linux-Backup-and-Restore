#include <iostream>
#include <bits/stdc++.h>
#include <stdexcept>
#include <stdio.h>
#include <string>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include "stdlib.h"
using namespace std;


int mmmx()
{
   char cwd[PATH_MAX];
   if (getcwd(cwd, sizeof(cwd)) != NULL)
   {
       printf("Current working dir: %s\n", cwd);
   }
   else
   {
       perror("getcwd() error");
       return 1;
   }
   return 0;
}


//using namespace std;
int main()
{

    system("sudo touch /etc/rear/local.conf");
    system("echo 'OUTPUT=USB\nBACKUP=NETFS\nBACKUP_URL=usb:///dev/disk/by-label/REAR-000' | sudo tee /etc/rear/local.conf");
    system("/home/Munam/Munam_Kazi.sh");



































    //cout<<"Please Enter Your Root Password.. \n\n\n";
    //system("/home/Munam/Munam_Kazi.sh");






//    int ch;
//    cin>>ch;
//    switch(ch)
//    {
//        case 1:
//            system("umount /dev/sdb*");
//            system("echo y | sudo mkfs /dev/sdb1");
//            system("dd if=/home/amit/Documents/PL1/OSD/boot/ubuntu-15.04-desktop-amd64.iso of=/dev/sdb");
//            system("echo n p ” \n\n\n\n\n” “w | fdisk /dev/sdb1");
//            break;
//    }

//    return 0;
    //system("sudo nano /etc/rear/local.conf");

//    ofstream MyFile("/etc/rear/local.conf");

//        // Write to the file
//        MyFile << "OUTPUT=USB" <<endl<<"BACKUP=NETFS"<<endl;
//               //<<BACKUP_URL="usb:///dev/disk/by-label/REAR-000";

//        // Close the file
//        MyFile.close();

        //system("cat /etc/rear/local.conf");
        //system("su");
        //system("sudo yum install rear syslinux-extlinux grub2-efi-x64-modules");
        //("rear format /dev/sdb");

        //system("rear -v mkbackup");
        //system("exit");
//        OUTPUT=USB
//        BACKUP=NETFS
//        BACKUP_URL="usb:///dev/disk/by-label/REAR-000"








          //char location[100] = "/etc/rear/local_munam.conf";
          //cout<<location<<endl;
        //ofstream MyFile(location);
//            // Write to the file

           // MyFile << "OUTPUT=USB" <<endl<<"BACKUP=NETFS"<<endl<<"BACKUP_URL=usb:///dev/disk/by-label/REAR-000";
//            // Close the file
           // MyFile.close();
//            //system("sudo rm /etc/rear/local.conf");
//            system("sudo cp -r /home/Munam/Documents/local.conf /etc/rear/local.conf");
//







}



//int main(){

//    mmmx();
//}




















//std::string exec(const char* pwd) {
//    char buffer[128];
//    std::string result = "";
//    FILE* pipe = popen(pwd, "r");
//    if (!pipe) throw std::runtime_error("popen() failed!");
//    try {
//        while (fgets(buffer, sizeof buffer, pipe) != NULL) {
//            result += buffer;
//        }
//    } catch (...) {
//        pclose(pipe);
//        throw;
//    }
//    pclose(pipe);
//    return result;
//}


//int main(){

//   cout<<exec("readlink -f UXBD.sh");
//}





//int main()
//{
    //char locat =0;
    //cout << "MUNAM UXBD!\n\n\n" << endl;

//    QString command="su";
//    system(command.toStdString().c_str());

    //system("su - root");
//    locat = system("source /home/Munam/Documents/first.sh");


//    cout <<locat;

//    cout <<"\n\n\n\n";
//    system("sudo lsblk | grep rom");
//    return 0;

//system("pwd");



// int main(){
//      int ret;
//      ret = system( "readlink -f UXBD.sh" );
//      printf( "system ret:[%d]\n", ret );
//}

    //int status = system("ls");
//    if (status < 0)
//        std::cout << "Error: " << strerror(errno) << '\n';
//    else
//    {
//        if (WIFEXITED(status))
//            std::cout << "Program returned normally, exit code " << WEXITSTATUS(status) << '\n';
//        else
//            std::cout << "Program exited abnormaly\n";
//    }


    //cout <<"\n\n\n"<<status<<"\n\n\n";
//}
