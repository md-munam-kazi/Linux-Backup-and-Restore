#ifndef INPUT_PASS_H
#define INPUT_PASS_H


class input_pass
{
public:
    input_pass();
};

#endif // INPUT_PASS_H
