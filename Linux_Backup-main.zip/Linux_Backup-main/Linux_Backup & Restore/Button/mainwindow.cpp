#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QDesktopServices>
#include <QUrl>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <QProcess>
#include <QStorageInfo>
#include <QDebug>
#include <QObject>
#include<bits/stdc++.h>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <iostream>

using namespace std;
//using namespace std::cout;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::munam() {
   char cwd[PATH_MAX];
   if (getcwd(cwd, sizeof(cwd)) != NULL) {
       printf("Current working dir: %s\n", cwd);
   } else {
       perror("getcwd() error");
       return 1;
   }
   return 0;
}

void MainWindow::on_pushButton_clicked()
{



  // QString mm ="/home/Munam/Desktop/uxbd.sh";

   // QString command="source u";
   //system("sudo su");
   //system("sudo yum update");
//char JJ ;
//QCoreApplication::applicationDirPath();
   //QString mm = { system("readlink -f UXBD.sh")};

   //system("ls");
//   system(mm.toStdString().c_str());
//   system(mm.toStdString().c_str());
//   system(mm.toStdString().c_str());




//system("echo 'munam143202' | sudo touch /etc/rear/ll.conf");



//system("sudo touch /etc/rear/ll.conf");
//system("echo 'munam143202' | sudo touch /etc/rear/ll.conf");











    QString fileName = QFileDialog::getExistingDirectory(this, tr("Open Directory"),
                                                 "/home",
                                                 QFileDialog::ShowDirsOnly
                                                 | QFileDialog::DontResolveSymlinks);
    //char x[100] = "/local.conf";
    string location = fileName.toStdString();
      location =location;
     //system(mmm.c_str());
     cout<<location<<endl;













     //system("sudo mkdir /etc/rear/lol");

//     ofstream MyFile();

//         // Write to the file
//         MyFile << "OUTPUT=USB" <<endl<<"BACKUP=NETFS"<<endl<<"BACKUP_URL=usb:///dev/disk/by-label/REAR-000";



//         // Close the file
//         MyFile.close();














   //QString fileName=QFileDialog::getOpenFileName(this,tr("Open File"),"/home/Munam");



 //  cout<<"File path: "<<fileName.toStdString()<<endl;


    //system("move \"x\\*\" \"mmm\" ");
//    string old_name = x;
//      string new_name = mmm;

//      if (rename(old_name.c_str(), new_name.c_str()) )
//        cout<< "Failure";
//      else
//        cout << "Success";

    //cout<<"   "<<mmm <<endl;


//char x[10] = "ls";

//    char x[300] = fileName.toStdString();
    //system(mmm.c_str());

//    char cmd;
//       strcpy(cmd,"ls");
//       system(cmd);




//    munam();

    //system(fileName.toStdString().c_str());
    //printf(fileName.toStdString().c_str());


    //QDir::currentPath();

  //  QDesktopServices::openUrl(QUrl("file:///"+fileName,QUrl::TolerantMode));



//    QString location;
//    QString path1= "/home/Munam/Documents/tttt";
//    QString locationoffolder="/home/Munam/Documents/test";

//    foreach (const QStorageInfo &storage, QStorageInfo::mountedVolumes()) {
//        if (storage.isValid() && storage.isReady() && (!(storage.name()).isEmpty())) {
//            if (!storage.isReadOnly()) {

//               qDebug() << "path:" << storage.rootPath();
//               //WILL CREATE A FILE IN A BUILD FOLDER
//               location = storage.rootPath();
//               QString srcPath = "/home/Munam/Documents/test";
//               //PATH OF THE FOLDER IN PENDRIVE
//               QString destPath = location+path1;
//               QString folderdir = location+locationoffolder;
//               //IF FOLDER IS NOT IN PENDRIVE THEN IT WILL CREATE A FOLDER NAME REPORT
//               QDir dir(folderdir);
//               if(!dir.exists()){
//                  dir.mkpath(".");
//               }

//               qDebug() << "Usbpath:" <<destPath;
//               if (QFile::exists(destPath)) QFile::remove(destPath);
//               QFile::copy(srcPath,destPath);
//               qDebug("copied");

//            }
//        }
//    }

//    void recursiveCopy(const QString& srcPath, const QString& dstPath) {
//      QDir().mkpath(dstPath); // be sure path exists

//      const QDir srcDir(srcPath);
//      Q_FOREACH (const auto& dirName, srcDir.entryList(QStringList(), QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {
//        recursiveCopy(srcPath + "/" + dirName, dstPath + "/" + dirName);
//      }

//      Q_FOREACH (const auto& fileName, srcDir.entryList(QStringList(), QDir::Files, QDir::Name)) {
//        QFile::copy(srcPath + "/" + fileName, dstPath + "/" + fileName);
//      }
//    }



    //    bool copyFiles() {
    //      const QString srcPath = QFileDialog::getOpenFileName(this, "Source file", "",
    //        "All files (*.*)");
    //      if (srcPath.isNull()) return false; // QFileDialog dialogs return null if user canceled

    //      const QString dstPath = QFileDialog::getSaveFileName(this, "Destination file", "",
    //        "All files (*.*)"); // it asks the user for overwriting existing files
    //      if (dstPath.isNull()) return false;

    //      if (QFile::exist(dstPath))
    //        if (!QFile::remove(dstPath)) return false; // couldn't delete file
    //          // probably write-protected or insufficient privileges

    //      return QFile::copy(srcPath, dstPath);
    //    }


//QMessageBox::information(this, tr("File Name"),fileName);


























}
