#ifndef MAINWINDOW_H
#define MAINWINDOW_H
//#ifndef FILES_H
//#define FILES_H

#include <QObject>

#include <QMainWindow>
//#include <windows.h>
#include <bits/stdc++.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    int munam();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
