sudo yum install -y rear syslinux-extlinux grub2-efi-x64-modules
sudo rear format /dev/sdb
sudo rear dump
sudo rear -v mkbackup
exit
