sudo yum update
